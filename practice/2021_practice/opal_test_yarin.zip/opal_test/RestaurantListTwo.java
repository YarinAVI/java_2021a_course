package opal_test;

public class RestaurantListTwo {
    private RestaurantNodeTwo _tail;
    private RestaurantNodeTwo _head;
    public RestaurantListTwo() {
        _tail = null;
        _head = null;
    }
    public int findMinDiff (String x, String y) {
        int Xindex = -1;
        int Yindex = -1;
        int index =1;
        int res = Integer.MAX_VALUE;
        //25,92,21,86,18,9,62,62,25,
        for(RestaurantNodeTwo iterator = _head;iterator!=null;iterator = iterator.getNext(),index++) {
            if(iterator.getFood().equals(x)) {
                Xindex = index;
                if(Math.abs(Yindex-Xindex) < res && Yindex!=-1) res =Math.abs(Yindex-Xindex);
            }
            else if(iterator.getFood().equals(y) ) {
                Yindex = index;
                if(Math.abs(Yindex-Xindex) < res && Xindex!=-1) res =Math.abs(Yindex-Xindex);
            }
        }


        return Yindex == -1 || Xindex == -1 ? Integer.MAX_VALUE : res;
    }
    public RestaurantNodeTwo getHead() {
        return _head;
    }
    public RestaurantNodeTwo getTail() {
        return _tail;
    }
    public void setHead(RestaurantNodeTwo _head) {
        this._head = _head;
    }
    public void setTail(RestaurantNodeTwo _tail) {
        this._tail = _tail;
    }
    public void insertNode(RestaurantNodeTwo in) {
        if(_tail==null && _head==null) {
            _tail = new RestaurantNodeTwo(in.getFood());
            _head = _tail;
        }
        else if(_tail == _head) {
            _head = new RestaurantNodeTwo(in.getFood());
            _head.setNext(_tail);
            _tail.setPrev(_head);
        }
        else {
            RestaurantNodeTwo ptr = new RestaurantNodeTwo(in.getFood());
            _head.setPrev(ptr);
            ptr.setNext(_head);
            _head = ptr;
        }
    }
    public void insertArray(int arr[]) {
        for(int i=0;i< arr.length;i++) {
            insertNode(new RestaurantNodeTwo(String.valueOf(arr[i])));
        }
    }
}
