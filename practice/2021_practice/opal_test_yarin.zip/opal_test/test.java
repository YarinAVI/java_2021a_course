package opal_test;
// by yarin avisidris <3
public class test {
    public static void main(String[] args) {
        RestaurantListTwo list = new RestaurantListTwo();
        /*
        list.insertNode(new RestaurantNodeTwo("Hamburger"));
        list.insertNode(new RestaurantNodeTwo("Pasta"));
        list.insertNode(new RestaurantNodeTwo("Shawarma"));
        list.insertNode(new RestaurantNodeTwo("Schnitzel"));
        list.insertNode(new RestaurantNodeTwo("Falafel"));
        list.insertNode(new RestaurantNodeTwo("Salad"));
        list.insertNode(new RestaurantNodeTwo("Steak"));
        list.insertNode(new RestaurantNodeTwo("Falafel"));
        list.insertNode(new RestaurantNodeTwo("Pizza"));
        System.out.println(list.findMinDiff("Falafel","Hamburger"));

         */

        /*
        list.insertNode(new RestaurantNodeTwo("3"));
        list.insertNode(new RestaurantNodeTwo("4"));
        list.insertNode(new RestaurantNodeTwo("2"));
        list.insertNode(new RestaurantNodeTwo("4"));
        list.insertNode(new RestaurantNodeTwo("5"));
        list.insertNode(new RestaurantNodeTwo("1"));
        list.insertNode(new RestaurantNodeTwo("7"));
        list.insertNode(new RestaurantNodeTwo("6"));
        list.insertNode(new RestaurantNodeTwo("3"));
        list.insertNode(new RestaurantNodeTwo("1"));
        System.out.println(list.findMinDiff("1","3"));
        */
        int test[] = {88,32,83,86,26,34,44,64,23,23,93,59,17,85,20,42,70,22,61,97,15,29,83,55,32,42,17,32,7,82,69,10,35,89,35,84,44,100,66,35,71,12,85,6,66,33,30,41,92,77,93,80,94,20,55,69,15,78,29,30,37,5,43,44,71,11,68,44,59,62,72,51,37,86,19,23,6,19,53,73,34,76,2,79,83,15,10,36,24,12,45,14,71,60,56,80,45,60,31,5};
        int arr[] = {25,62,62,9,18,86,21,92,25};
        System.out.println();
        list.insertArray(arr);
        System.out.println(list.findMinDiff("25","62"));
        //list.insertArray(test);
        //System.out.println(list.findMinDiff("64","44"));

    }
}
