package opal_test;
public class RestaurantNodeTwo
{
    private String _food;
    private RestaurantNodeTwo _next;
    private RestaurantNodeTwo _prev;
    public RestaurantNodeTwo(String in) {
        this._food = in;
        this._next = null;
        this._prev = null;
    }
    public RestaurantNodeTwo getNext() {
        return _next;
    }
    public RestaurantNodeTwo getPrev() {
        return _prev;
    }
    public String getFood() {
        return _food;
    }
    public void setFood(String _food) {
        this._food = _food;
    }

    public void setNext(RestaurantNodeTwo _next) {
        this._next = _next;
    }

    public void setPrev(RestaurantNodeTwo _prev) {
        this._prev = _prev;
    }
}
